# Webpack & Tailwind Starter

Build apps with Webpack and use Tailwind CSS

## Usage

### Install dependencies

```
npm Install
```

### Build for production

```
npm run build
```

### Run the development server (:3000)

```
npm run dev
```

### Gist File With Steps To Create This
https://gist.github.com/bradtraversy/1c93938c1fe4f10d1e5b0532ae22e16a
