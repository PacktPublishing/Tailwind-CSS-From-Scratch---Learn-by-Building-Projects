# Pricing Cards Project

Pricing Cards mini-project from my Tailwind course.

![Alt text](images/pricing-cards.png)
