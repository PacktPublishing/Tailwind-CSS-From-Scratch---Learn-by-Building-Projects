# Clipboard Website

Clipboard landing page from my Tailwind course and from [Frontend Mentor Challenge](https://www.frontendmentor.io/challenges/clipboard-landing-page-5cc9bccd6c4c91111378ecb9)

## Usage

Install dependencies

```
npm Install
```

Run Tailwind CLI

```
npm run watch
```

![Alt text](images/clipboard.png)
