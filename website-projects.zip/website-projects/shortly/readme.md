# Shortly Website

Shortly landing page from my Tailwind course and from [Frontend Mentor Challenge](https://www.frontendmentor.io/challenges/url-shortening-api-landing-page-2ce3ob-G)

## Usage

Install dependencies

```
npm Install
```

Run Tailwind CLI

```
npm run watch
```

![Alt text](images/shortly.png)
